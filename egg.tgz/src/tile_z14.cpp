// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Pack zoom-14 tiles");
  std::fflush(stdout);
  return lionss_run_workload("tile_z14");
}
