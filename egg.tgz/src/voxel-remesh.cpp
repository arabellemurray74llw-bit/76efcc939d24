// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Remesh voxel volume"); }
int main(){
  announce();
  return lionss_run_workload("voxel-remesh");
}
