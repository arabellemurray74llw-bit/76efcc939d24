// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode 48k stream\n", stdout);
  return lionss_run_workload("opus_encode48k");
}
