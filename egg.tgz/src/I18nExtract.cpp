// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Extract i18n messages\n", stdout);
  return lionss_run_workload("I18nExtract");
}
