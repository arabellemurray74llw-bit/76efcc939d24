// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Skip via zone maps\n", stdout);
  return lionss_run_workload("zonemapskip");
}
