// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Lint helm chart\n", stdout);
  return lionss_run_workload("helmLint");
}
