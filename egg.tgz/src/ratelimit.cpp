// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Load-test token bucket"); }
int main(){
  announce();
  return lionss_run_workload("ratelimit");
}
